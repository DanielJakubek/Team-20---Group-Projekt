public interface UndoableCommand {
	void undo();//This will be the inverse of the original method being called
}