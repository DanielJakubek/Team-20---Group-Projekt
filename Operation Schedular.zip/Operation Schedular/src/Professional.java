
public class Professional {

}
